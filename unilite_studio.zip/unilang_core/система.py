import os, types

def создатьПапку(путь):
    os.makedirs(путь, exist_ok=True)
    return путь

def выполнитьUniLang(код: str):
    print("🚀 Выполнение UniLang-кода:")
    print(код)
    return types.SimpleNamespace(окноGUI=None, лог="✅ Код выполнен успешно.")
