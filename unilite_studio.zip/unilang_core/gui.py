import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

class Окно:
    def __init__(self, заголовок, ширина=800, высота=600, тема="светлая"):
        self.root = tk.Tk()
        self.root.title(заголовок)
        self.root.geometry(f"{ширина}x{высота}")

    def добавить(self, элемент):
        if hasattr(элемент, 'render'):
            элемент.render(self.root)

    def показать(self):
        self.root.mainloop()

class Меню:
    def __init__(self):
        self.frame = None
        self.buttons = []

    def добавитьКнопку(self, текст, действие):
        self.buttons.append((текст, действие))

    def render(self, root):
        frame = ttk.Frame(root)
        frame.pack(side='top', fill='x')
        for text, action in self.buttons:
            b = ttk.Button(frame, text=text, command=action)
            b.pack(side='left', padx=2, pady=2)
        self.frame = frame

class ТекстовоеПоле:
    def __init__(self, многострочное=False, readonly=False, авто_прокрутка=False):
        self.text = None
        self.readonly = readonly

    def render(self, root):
        self.text = tk.Text(root)
        self.text.pack(fill='both', expand=True)

    def добавитьТекст(self, txt):
        if self.text:
            self.text.insert('end', txt)
            self.text.see('end')

    def очистить(self):
        if self.text:
            self.text.delete('1.0', 'end')

def Сообщение(заголовок, текст):
    messagebox.showinfo(заголовок, текст)

def Ввод(текст):
    return simpledialog.askstring("Ввод", текст)
